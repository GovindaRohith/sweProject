import React, { useState, useEffect } from 'react';
import axios from './axios';
export default function AllotHR() {
  // use states for the form inputs
    return (
        <div>
            <h1>Allot HR</h1>
        </div>
    );
}