import React, { useState, useEffect } from 'react';
import axios from './axios';
export default function HOCheckin() {
  // use states for the form inputs
    return (
        <div>
            <h1>Checkin</h1>
        </div>
    );
}

