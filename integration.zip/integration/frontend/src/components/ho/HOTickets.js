import React, { useState, useEffect } from 'react';
import axios from './axios';
export default function HOTickets() {
  // use states for the form inputs
    return (
        <div>
          Tickets
        </div>
    );
}

