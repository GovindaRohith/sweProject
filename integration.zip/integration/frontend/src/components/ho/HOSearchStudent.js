import React, { useState, useEffect } from 'react';
import axios from './axios';
export default function HOSearchStudent() {
  // use states for the form inputs
    return (
        <div>
            <h1>Search Student</h1>
        </div>
    );
}

