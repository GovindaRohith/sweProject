import React, { useState, useEffect } from 'react';
import axios from './axios';
import DisplayTickets from './DisplayTickets';
// import ticket_details from './ticket_details';
export default function Login() {
  // use states for the form inputs
  
    return (
        <div>
            <DisplayTickets/>
        </div>
    );
}

