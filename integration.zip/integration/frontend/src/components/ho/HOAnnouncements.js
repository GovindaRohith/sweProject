import React, { useState, useEffect } from 'react';
import axios from './axios';
export default function HOAnnouncements() {
  // use states for the form inputs
  
    return (
        <div>
            <h1>Announcements</h1>
        </div>
    );
}

